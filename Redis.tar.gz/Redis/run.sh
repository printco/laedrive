#!/bin/bash

redis_host="cache-cluster-lmssit-lmsapi-bluegw-001.cache-cluster-lmssit-lmsapi-bluegw.nhojmy.apse1.cache.amazonaws.com"
redis_pass="7lF35SHgBJ7mTToanou"
java -cp JedisConnector.jar Redis.JedisConnector $redis_host 6379 bluegw $redis_pass ssl

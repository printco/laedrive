with c as (
	select id as cardid,compid,c.cardnum,taxaddrid,cardname,c.blockcode,plate,vehbrand,vehtype,deptname,costcenter,limtype,translimb,daylimb,weeklimb,monthlimb,transliml,dayliml,weekliml,monthliml,prodperm,n.cardnumseq
	,accode,odochk
	from card c
	join cardnum n on c.cardnum = n.cardnum
	where 1=1
	--and cardnum = '7a6517267bdfcf6448065e76cc69ba398bb90a9514e8a0041f1194f09e4ed7e6'
	union all
	select cardid,ccompid,cardnum,ctaxaddrid,ccardname,blockcode,cplate,cvehbrand,cvehtype,cdeptname,ccostcenter,climtype,ctranslimb,cdaylimb,cweeklimb,cmonthlimb,ctransliml,cdayliml,cweekliml,cmonthliml,cprodperm,cardnumseq 
	,caccode,0 as odochk
	from cardnum
	where seq <> 0
	--and cardnum = '7a6517267bdfcf6448065e76cc69ba398bb90a9514e8a0041f1194f09e4ed7e6'
)
select
	 p.compid	as 'Account No.'												-- 1
	,p.compname	as 'Account Name'												-- 2
	,pm.name as 'Fix Service Station'											-- 3
	,o.orgtypename as 'Orginization Type'										-- 4
	,(case when p.compchainid is null then p.wtrate 
		else ( case when cc.iswth = 1 
				then  (case when isnull((case when p.compchainid is null then p.taxid 
						else (case when cc.iswth = 1 then cc.taxid else p.taxid end)
						end),'') = '' then 0 else cc.wtrate end)
				else (case when isnull((case when p.compchainid is null then p.taxid 
						else (case when cc.iswth = 1 then cc.taxid else p.taxid end)
						end),'') = '' then 0 else p.wtrate end) 
				end)  
		end) as 'Tax Rate'														-- 5
	,(case when p.compchainid is null then p.taxid 
		else (case when cc.iswth = 1 then cc.taxid else p.taxid end)
		end) as 'Tax ID'														-- 6
	,(case when p.compchainid is null then 'None' 
		else cc.chiefmer + '-' + cc.compchainname
		end) as 'Belong to Customer Chain'										-- 7
	,(case when p.compchainid is null then 'No' 
		else (case when cc.iswthcer=1 then 'Yes' else 'No' end) 
		end) as 'Choose Witholding Tax'											-- 8
	,cd.cdomname as 'Domain'													-- 9
	,ta.addr as 'EDC Tax Address'												--10
	,'decrypt=' + c.cardnum as 'Card No.'										--11
	,c.cardname	as 'Cardholder Name'											--12
	,c.blockcode as 'Block Code'												--13
	,c.plate as 'Plat No.'														--14
	,c.vehbrand	as 'Brand'														--15
	,c.vehtype as 'Type'														--16
	,c.deptname	as 'Dept'														--17
	,c.costcenter as 'Cost Center'												--18
	,cardxml.prodperm as 'Product Permission'									--19,20,21,22
	,c.limtype as 'Limit Type'													--23
	,case when c.limtype = 'B' then c.translimb 
		else c.transliml end as 'Limit per trans'								--24
	,case when c.limtype = 'B' then c.daylimb 
		else c.dayliml end as 'Limit per day'									--25
	,case when c.limtype = 'B' then c.weeklimb 
		else c.weekliml end as 'Limit per week'									--26
	,case when c.limtype = 'B' then c.monthlimb 
		else c.monthliml end as 'Limit per month'								--27
	,accode as 'Account Code'													--28
	,case when c.odochk = 1 then 'Check' 
		else '' end as 'Odometer Validation'									--29
	,case when k.isautotopup = 1 then 'Allow Auto Request Topup' 
		else NULL end as 'ARTU'													--30
	,k.name	as 'Topup Option'													--31
	,k.topupopt	as 'Option detail'												--32
	,k.topuptarget	as 'Topup Target'											--33
from comp p
left join c on c.compid = p.compid
left join permmode pm on pm.code = p.merpermmode
left join compchain cc on cc.compchainid = p.compchainid
left join orgtype o on o.orgtypeid = (case when p.compchainid is null then p.orgtypeid else cc.orgtypeid end)
left join cdom cd on cd.cdomid = (case when p.compchainid is null then p.cdom else cc.cdom end)
left join taxaddr ta on ta.id = c.taxaddrid
left join (
	select cardnum,stuff((select ',' + prodcode + ' - ' + prodname  
		from c c1 
		left join prodperm pp on pp.id=c1.prodperm 
		left join prod p on p.id = pp.prodid
		where c1.cardnum=c2.cardnum for xml path('')),1,1,'')  as prodperm
	from c c2
	group by cardnum
)cardxml on cardxml.cardnum = c.cardnum
left join (
	select compid,cardnum
	,isautotopup
	,t.name
	,ignoreartu
	,(case 
		when topupoption in (0,-1) then t.name
		when topupoption = 1 then '00:00'
		when topupoption = 2 then d.dow
		when topupoption = 3 then cast(topupdom as varchar) 
		else NULL
		end) as topupopt
	,topuptarget
	from (
		select 
		p.compid,isautotopup,ignoreartu ,p.topupopt as comptopupoption,p.topupdow as comptopupdow,p.topupdom as comptopupdom
		,c.cardnum,c.topupopt as cardtopupoption,c.topupdow as cardtopupdow,c.topupdom as cardtopupdom
		------------------------------------------------------------------------
		,(case when p.isautotopup = 1 then (case when p.ignoreartu = 1 then /*from comp*/p.topupopt else /*from card*/c.topupopt end) else /*uncheck*/-2 end) as topupoption
		,(case when p.isautotopup = 1 then (case when p.ignoreartu = 1 then /*from comp*/p.topupdow else /*from card*/c.topupdow end) else /*uncheck*/0 end) as topupdow
		,(case when p.isautotopup = 1 then (case when p.ignoreartu = 1 then /*from comp*/p.topupdom else /*from card*/c.topupdom end) else /*uncheck*/0 end) as topupdom
		,(case when p.isautotopup = 1 then c.topuptarget else 0 end) as topuptarget
		------------------------------------------------------------------------
		from comp p
		left join (
			select compid ,topupopt ,topupdow ,topupdom ,topuptarget ,cardnum from card where cardtypeid = 6 union all
			select ccompid,ctopupopt,ctopupdow,ctopupdom,ctopuptarget,cardnum from cardnum where seq <> 0 and ccardtypeid = 6
		) c on p.compid = c.compid
		--where p.compid = '9990410000331886'
	)a
	left join topupopt t on a.topupoption = t.id
	left join (
		select 1 as seq,'Sunday' as dow union all
		select 2 as seq,'Monday' as dow union all
		select 3 as seq,'Tuesday' as dow union all
		select 4 as seq,'Wednesday' as dow union all
		select 5 as seq,'Thursday' as dow union all
		select 6 as seq,'Friday' as dow union all
		select 7 as seq,'Saturday' as dow 
	)d on d.seq = (case when a.topupoption = 2 then a.topupdow else 0 end)
)k on k.compid = c.compid and k.cardnum = c.cardnum
where 1=1
--and p.compid in ( '9990410000331886' , '9990930004916292' )
--and c.cardnum = '23946a5d1a89d5840f8a93a043e39d643d9de1e2b918c894f53b7fe7b6a78953'
/*replace_here*/order by p.compid,cardnumseq asc
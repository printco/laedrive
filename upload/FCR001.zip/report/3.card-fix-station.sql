with m as (
	select c.compid,c.cardnum,mp.merid,merpermmode,cardnumseq from (
		select c.compid,c.cardnum,c.merperm,c.merpermmode,n.cardnumseq from card c left join cardnum n on c.cardnum = n.cardnum 
		union all
		select ccompid,cardnum,cmerperm,cmerpermmode,cardnumseq from cardnum where seq <> 0
	)c
	left join merperm mp on mp.id = c.merperm
)
select compid as 'Account No.'
	,'decrypt=' + cardnum as 'Card No.'
	,name as 'Fix Service Station'
	,stuff((select ',' + merid from m m1 where m1.cardnum = m.cardnum for xml path('')),1,1,'') as 'Allow Mechants'
from m
left join permmode pm on pm.code = merpermmode
where m.merpermmode = 2
group by m.compid,cardnum,pm.name,m.cardnumseq
/*replace_here*/order by m.cardnumseq
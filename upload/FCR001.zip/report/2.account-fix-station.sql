with m as (
	select p.compid,mp.merid,merpermmode from comp p
	left join merperm mp on mp.id = p.merperm
	--where p.compid = '1100000000000011'
)
select compid as 'Account No.'
	, name as 'Fix Service Station'
	, stuff((select ',' + merid from m m1 where m1.compid = m.compid for xml path('')),1,1,'') as 'Allow Mechants'
from m
left join permmode pm on pm.code = merpermmode
where m.merpermmode = 2
group by m.compid,pm.name
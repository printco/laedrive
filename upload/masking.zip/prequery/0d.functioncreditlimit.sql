create function ufn_creditlimit
(@cycle int,@used money,@usedenddt varchar(14),@monthstartdt datetime)
returns money
as
begin

	if @usedenddt is null or @monthstartdt is null return 0

	declare @now datetime = getdate()
		,@return_used money

	set @usedenddt = left(@usedenddt + '00000000000000',14)

	select @return_used = (case when dbo.ymdhis2date(@usedenddt) <= @monthstartdt then 0 else @used end)
	return @return_used
end;
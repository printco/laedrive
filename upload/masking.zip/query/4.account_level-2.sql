select act_idn_sky
,case when min_bcv_amt is null then isnull(min_bcv_amt,'') else replace(cast(min_bcv_amt as varchar),'.','') end as min_bcv_amt
,apm_lth_cde,tax_ctt_idn_sky
,replace(cast(crt_bal_amt as varchar),'.','') as crt_bal_amt
,replace(cast(osg_ath_amt as varchar),'.','') as osg_ath_amt
,'813' as ise_bch_idn
,substring(upper(dmn_txt),1,4) as dmn_txt
from (
	-- comp
	select p.compid as ordercolumn
		,1 as orderrow
		,p.compid as act_idn_sky 
		,'' as min_bcv_amt
		,(case when isnull(topupopt,0) = 0 then ''
			when topupopt = 1 then 'DALY'
			when topupopt = 2 then 'WEEK'
			when topupopt = 3 then 'MNTH'
		  end) as apm_lth_cde
		,isnull(p.taxid,'') as tax_ctt_idn_sky
		,'' as crt_bal_amt
		,'' as osg_ath_amt
		,p.taxbrn as ise_bch_idn
		,isnull(d.cdomname,'') as dmn_txt
	from comp p
	left join cdom d on p.cdom = d.cdomid
	where 1=1
	--and p.compstatus = 1
	--and p.isprepaid = 1
	--and p.isautotopup = 1
	union all
	-- card
	select p.compid as ordercolumn
		,2 as orderrow
		,'maskcard='+c.cardnum as act_idn_sky 
		,cast(c.topuptarget as varchar(20)) as min_bcv_amt
		,(case when isnull(p.topupopt,0) = 0 then ''
			when p.topupopt = 1 then 'DALY'
			when p.topupopt = 2 then 'WEEK'
			when p.topupopt = 3 then 'MNTH'
		  end) as apm_lth_cde
		,'' as tax_ctt_idn_sky
		,(c.credused) as crt_bal_amt
		,isnull(cast(t.osg_ath_amt as varchar(20)),'0.00') as osg_ath_amt
		,p.taxbrn as ise_bch_idn
		,'' as dmn_txt
	from (
		select id,cardnum,compid,credused,topuptarget from card
		union all
		select cardid,cardnum,ccompid,ccredused,ctopuptarget from cardnum where seq <> 0
	) c
	join comp p on p.compid = c.compid
	left join (
		select cardnum,sum(amt) as osg_ath_amt 
		from trans
		where dbo.ymdhis2date(transdt) >= dateadd(day,-59,(select dbo.ymd2date( max(transd) ) from transd))
		and transstate in (6,9)
		group by cardnum
	)t on c.cardnum = t.cardnum
	where 1=1
	--and p.compstatus = 1
	--and p.isprepaid = 1
	--and p.isautotopup = 1
)a
--where a.ordercolumn = '1100000000000006'
/*replace_here*/order by a.ordercolumn,a.orderrow
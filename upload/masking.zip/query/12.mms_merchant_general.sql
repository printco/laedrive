select
    m.merid as mht_itl_nbr
     , m.stationid as sta_id
     , substring(UPPER(p.pcompname),1,4) as com_id
     , o.oomcode as mht_oom_cde
     , m.provcode as mht_prv_cde
     , m.ampcode as mht_dit_cde
     , m.tamcode as mht_sub_dit_cde
from mer m
         left join pcomp p on p.pcompid = m.pcompid
         left join oom o on o.oomid = m.oomid
/*replace_here*/order by m.merid
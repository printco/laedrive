select
    'maskcard=' + c.cardnum as pan_txt
     ,CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' END as app_lmt_ctl_mod
	 ,(case when taxaddrid < 0 then NULL else taxaddrid end) as adr_key
from (
	select id,cardnum,compid,limtype,taxaddrid from card
	--where compid = '1100000000000244'
	union all
	select cardid,cardnum,ccompid,climtype,ctaxaddrid from cardnum 
	where seq <> 0
	--and ccompid = '1100000000000244'
)c
left join dbo.cardnum n on c.cardnum = n.cardnum
/*replace_here*/order by c.compid, n.cardnumseq
with t as (
	select * from trans 
	where substring(transdt,1,8) >= convert(varchar,dateadd(day,-60,cast('2022-03-01' as date)),112)
)
select (case when src='card' then 'decrypt=' else '' end) + act_idn_sky as 'act_idn_sky',min_bcv_amt,apm_lth_cde,tax_ctt_idn_sky,crt_bal_amt,osg_ath_amt,ise_bch_idn,dmn_txt
from (
         select co.compid								as act_idn_sky
              , CAST(co.topuptarget as numeric(17,2))as min_bcv_amt
              , case when co.topupopt=1 then 'DALY'
                     else case when co.topupopt=2 then 'WEEK'
                               else case when co.topupopt=3 then 'MNTH'
                                         else null end end end				as apm_lth_cde
              , case when cc.iswthcer = 1 and cc.iswth = 1 then cc.taxid
                     when cc.iswthcer = 0 and co.iswth = 1 then co.taxid
                     when co.iswth = 1 then co.taxid  end	as tax_ctt_idn_sky
              , CAST(co.credline - co.credused as numeric(17,2))	as crt_bal_amt
              , CAST(t.amt as numeric(17,2))			as osg_ath_amt
              , co.taxbrn							as ise_bch_idn
              , c2.cdomname							as dmn_txt
              , 'comp'								as src
              , co.compid							as compid
         from comp co
                  left join (select compid,sum(amt) as amt from t
                             where transstate in (6, 9)
                             group by compid
         )t on t.compid = co.compid
                  left join compchain cc on cc.compchainid = co.compchainid
                  left join cdom c2 on c2.cdomid = coalesce(co.cdom,cc.cdom)
         union all
         select c.cardnum								as act_idn_sky
              , CAST(c.topuptarget as numeric(17,2))	as min_bcv_amt
              , case when c.topupopt=1 then 'DALY'
                     else case when c.topupopt=2 then 'WEEK'
                               else case when c.topupopt=3 then 'MNTH'
                                         else case when c.topupopt=-1 then case when co.topupopt=1 then 'DALY'
                                                                                else case when co.topupopt=2 then 'WEEK'
                                                                                          else case when co.topupopt=3 then 'MNTH'
                                                                                                    else null end end end
                                             end end end end					as apm_lth_cde
              , case when cc.iswthcer = 1 and cc.iswth = 1 then cc.taxid
                     when cc.iswthcer = 0 and co.iswth = 1 then co.taxid
                     when co.iswth = 1 then co.taxid  end	as tax_ctt_idn_sky
              , CAST(c.credline - c.credused as numeric(17,2))		as crt_bal_amt
              , t.amt    as osg_ath_amt
              , co.taxbrn     as ise_bch_idn
              , c2.cdomname       as dmn_txt
              , 'card'		   as src
              , co.compid							as compid
         from card c
                  left join comp co on co.compid = c.compid
                  left join (select compid,cardnum,sum(amt) as amt from t
                             where transstate in (6, 9)
                             group by compid,cardnum
         )t on t.compid = co.compid and t.cardnum = c.cardnum
                  left join compchain cc on cc.compchainid = co.compchainid
                  left join cdom c2 on c2.cdomid = coalesce(co.cdom,cc.cdom)
     ) as acc
/*replace_here*/order by acc.compid,acc.src desc,acc.act_idn_sky
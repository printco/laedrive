select
termid as tml_idn_txt
, merid as mht_itl_nbr
, (case when termstatus = 'A' then 1 else 0 end) as tml_sts
, cast(cast(dbo.ymd2date(lastdate) as date) as varchar(10)) as lst_dte
, sbatch as stl_bth_nbr
, nextrefnum as nxt_ref_nbr
, lastinvoice as lst_ivc_nbr
, convert(varchar,dbo.ymd2date(lasttransd),23)  as lst_trn_dte
, convert(varchar,dbo.ymd2date(lastinvoicedate),23) as lst_ivc_dte
from term
/*replace_here*/order by termid

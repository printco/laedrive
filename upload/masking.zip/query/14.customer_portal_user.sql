select * from (
	select
	  (case when g.grptypeid in (2) then substring(d.cdomname,1,4) else coalesce(u.compid,cc.chiefmer) end ) as csr_idn_sky
	, 'Other' as rol_typ
	, (case when u.lname is null or u.lname = '' then usrname else u.lname end) as sur_nme
	, 'maskemail=' + u.email as eml_adr
	, u.usrname as ptl_usr_id
	from tfcweb.dbo.usr u
	left join tfcweb.dbo.grp g on u.grpid = g.grpid
	left join tfcweb.dbo.grptype t on t.grptypeid = g.grptypeid
	left join compchain cc on cc.compchainid = u.compchainid
	left join cdom d on d.cdomid = u.cdomid
	where g.grptypeid in (1,2,3) and u.deletedt is null and u.deleter is null and u.email is not null
union all
	select
	  (case when g.grptypeid in (2) then substring(d.cdomname,1,4) else coalesce(u.compid,cc.chiefmer) end ) as csr_idn_sky
	, 'Maker' as rol_typ
	, (case when u.lname is null or u.lname = '' then usrname else u.lname end) as sur_nme
	, (case when u.otpemail is null or u.otpemail = '' then 'Migration' else u.otpemail end) as eml_adr
	, u.usrname as ptl_usr_id
	from tfcweb.dbo.usr u
	left join tfcweb.dbo.grp g on u.grpid = g.grpid
	left join tfcweb.dbo.grptype t on t.grptypeid = g.grptypeid
	left join compchain cc on cc.compchainid = u.compchainid
	left join cdom d on d.cdomid = u.cdomid
	where g.grptypeid in (1,2,3) and u.deletedt is null and u.deleter is null and u.otpemail is not null 
) u
/*replace_here*/order by ptl_usr_id


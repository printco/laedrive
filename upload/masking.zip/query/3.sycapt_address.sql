with a as (
	select * from edcaddr
)
, b as (
	select * from whtaddr
)
select * from (
	select co.compid                                                    as ctt_adr_idn_sky
		, ROW_NUMBER() OVER (PARTITION BY co.compid ORDER By co.compid) as seq_nbr
		, a.id															as adr_key
		, 'TAXA'                                                        as adr_typ_cde
		, a.compname                                                    as adr_Crop_name
		, a.addrno														as adr_ln1_txt
		, a.village														as adr_ln2_txt
		, a.room                                                        as adr_ln3_txt
		, a.flr															as adr_ln4_txt
		, a.moo                                                         as adr_ln5_txt
		, a.soi                                                         as adr_ln6_txt
		, a.road                                                        as adr_ln7_txt
		, a.tambon                                                      as adr_ln8_txt
		, a.taxid														as tax_id
		, a.branch														as brc_nbr
		, a.amphoe														as adr_cty_txt
		, a.prov														as adr_sae_txt
		, 'THAILAND'                                                    as adr_cny_txt
		, a.zipcode                                                     as adr_psl_cde_txt
		, 'maskcontact='+a.phone                                        as adr_phe_txt
		, a.ext                                                         as adr_ext_txt
		, 'maskcontact='+co.fax                                         as adr_fax_txt
	from comp co
	left join (
		select ROW_NUMBER() over(partition by compid order by compid) as seq
		,id,compid from edcaddr
	) t on co.compid = t.compid
	left join a on a.id = t.id
	where co.iswth = 0
union all
	select co.compid                                                    as ctt_adr_idn_sky
		, ROW_NUMBER() OVER (PARTITION BY co.compid ORDER By co.compid) as seq_nbr
		, ''															as adr_key
		, 'OTHR'                                                        as adr_typ_cde
		, b.taxname                                                     as adr_Crop_name
		, b.addrno														as adr_ln1_txt
		, b.village														as adr_ln2_txt
		, b.room                                                        as adr_ln3_txt
		, b.flr															as adr_ln4_txt
		, b.moo                                                         as adr_ln5_txt
		, b.soi                                                         as adr_ln6_txt
		, b.road                                                        as adr_ln7_txt
		, b.tambon                                                      as adr_ln8_txt
		, co.taxid                                                      as tax_id
		, co.taxbrn                                                     as brc_nbr
		, b.amphoe														as adr_cty_txt
		, b.prov														as adr_sae_txt
		, 'THAILAND'                                                    as adr_cny_txt
		, b.zipcode                                                     as adr_psl_cde_txt
		, 'maskcontact='+b.phone                                        as adr_phe_txt
		, b.ext                                                         as adr_ext_txt
		, 'maskcontact='+co.fax                                         as adr_fax_txt
	from comp co
	left join b on co.taxid = b.taxid and right('000000' + co.taxbrn,6) = right('000000' + b.taxbrn,6)
	where iswth = 1
)c
/*replace_here*/order by adr_typ_cde,ctt_adr_idn_sky,seq_nbr

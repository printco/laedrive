select
u.merid as csr_idn_sky
,'maskemail='+ u.email as eml_adr
, u.usrname as ptl_usr_id
from tfcweb.dbo.usr u
left join tfcweb.dbo.grp g on u.grpid = g.grpid
left join tfcweb.dbo.grptype t on t.grptypeid = g.grptypeid
where t.grptypeid in ( 5 ) and u.deletedt is null and u.deleter is null
with d as (
    select  p.compid,pc.pcompname, o.oomcode
    from comp p
    join pcompperm pm on p.pcompperm = pm.id
    join pcomp pc on pc.pcompid = pm.pcompid
    join pcompoomperm po on po.id = p.pcompoomperm and po.pcompid = pc.pcompid
    join oom o on o.oomid = po.oomid
    where compstatus = 1
	--and compid in ('1100000000000003','1100000000000004')
    group by p.compid,pc.pcompname,o.oomcode
)
select compid as act_idn_sky , stuff((
	select ';' + upper(comp_prm_grp) 
	from (
		select compid,pcompname + '|' + stuff((
			select '|' + oomcode
			from d
			where d.compid = d2.compid and d.pcompname = d2.pcompname
			for xml path('')
		),1,1,'') as 'comp_prm_grp'
		from d d2
		group by compid,pcompname
	)
	y
	where y.compid = d3.compid
	for xml path('')
),1,1,'') as comp_prm_grp
from d d3
group by compid
/*replace_here*/order by compid

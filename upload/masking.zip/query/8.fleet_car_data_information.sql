select 'maskcard='+c.cardnum as pan_txt
     , (case when c.cardname is null or c.cardname = '' then ' ' else replace(c.cardname,'"','""') end) as csr_nme
     , case when ct.cardtypename = 'General' then 'GNRL'
            when ct.cardtypename = 'In-house' then 'TKCR'
            when ct.cardtypename = 'ทูอินวัน' then '2IN1'
            when ct.cardtypename is not null then 'GNRL'  end as pla_pdt_typ_cde
     , c.plate as car_lic
     , c.vehbrand as car_brd
     , c.vehtype as car_typ
     , c.odochk as odom_chk_flg
     , c.lastodo as odom_acul
     , c.limtype as usg_lmt_flg
     , c.costcenter as cst_ctr_txt
	 , c.deptname as dpt_txt
	 , c.accode as act_cde
from card c
left join cardnum n on c.cardnum = n.cardnum
         left join cardtype ct on ct.id = c.cardtypeid
/*replace_here*/order by n.cardnumseq
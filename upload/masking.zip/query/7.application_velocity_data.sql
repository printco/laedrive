with ac as (
	select c.*,m.cyclestartday,monthstartdt,monthenddt,weekstartdt,weekenddt,daystartdt,dayenddt
	from (
		select id,compid,c1.cardnum,limtype,monthlimb,monthliml,monthusedl,monthusedb,weeklimb,weekusedb,weekliml,weekusedl,daylimb,dayliml,dayusedb,dayusedl,translimb,transliml
		,dayusedstart,dayusedend,weekusedstart,weekusedend,monthusedstart,monthusedend
		,cardnumseq
		from card c1
		join (select cardnum,cardnumseq from cardnum where seq = 0) c2 on c1.cardnum = c2.cardnum
		where 1=1
		--and c1.cardnum = '32887562a99bd4d4e2e484a19f8e601c94bd96a20b0c70569bc49d963e77e364'
		union all
		select cardid,ccompid,cardnum,climtype,cmonthlimb,cmonthliml,cmonthusedl,cmonthusedb,cweeklimb,cweekusedb,cweekliml,cweekusedl,cdaylimb,cdayliml,cdayusedb,cdayusedl,ctranslimb,ctransliml 
		,cdayusedstart,cdayusedend,cweekusedstart,cweekusedend,cmonthusedstart,cmonthusedend
		,cardnumseq
		from cardnum where seq <> 0
		--and cardnum = '32887562a99bd4d4e2e484a19f8e601c94bd96a20b0c70569bc49d963e77e364' 
	)c
	left join (
		select c.compid,cyclestartday,monthstartdt,monthenddt
		,dbo.findweekstart(getdate()) weekstartdt,dateadd(day, 7, dbo.findweekstart(getdate())) weekenddt
		,dbo.finddaystart(getdate()) daystartdt,dbo.finddaystart(getdate())+1 dayenddt
		from comp c
		left join (
			select compid,max(ym) maxym
				,max(cyclestartdt) monthstartdt 
				,max(cycleenddt) monthenddt
			from cyclehist
			group by compid
		) cl on c.compid = cl.compid
	) m on c.compid = m.compid 
)
select 
	'maskcard='+pan_txt as 'pan_txt',vty_chk_prd_typ,vty_chk_typ,vty_stt_dte
	,replace(cast(isnull(vty_chk_lmt_amt,0.00) as varchar),'.','') as vty_chk_lmt_amt
	,vty_chk_lmt_cnt
	,replace(cast(isnull(vty_chk_accm_amt,0.00) as varchar),'.','') as vty_chk_accm_amt
	,vty_chk_accm_cnt
	,replace(cast(isnull(vty_chk_lmt_lter,0.00) as varchar),'.','') as vty_chk_lmt_lter
	,replace(cast(isnull(vty_chk_accm_lter,0.00) as varchar),'.','') as vty_chk_accm_lter
from
    (
        select compid,cardnumseq,cardnum															as pan_txt
             , 'CYCL'																				as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END		as vty_chk_typ
             , '1800-01-01'																			as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(monthlimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	0.00	END												as vty_chk_lmt_amt
             , 0																					as vty_chk_lmt_cnt
             , CASE WHEN limtype = 'B' THEN dbo.ufn_creditlimit(ac.cyclestartday,monthusedb,ac.monthusedend,monthstartdt)
					WHEN limtype = 'L' THEN 0.00 END												as vty_chk_accm_amt
             , 0																					as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN CAST(monthliml as numeric(17,2)) END					as vty_chk_lmt_lter
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN dbo.ufn_creditlimit(ac.cyclestartday,monthusedl,ac.monthusedend,monthstartdt) END				
			 																						as vty_chk_accm_lter
			 , 1 as typeseq
        from ac
        --where not (monthlimb is null and monthliml is null)
        union all
        select compid,cardnumseq,cardnum															as pan_txt
             , 'FXWK'																				as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END		as vty_chk_typ
             , '1800-01-01'																			as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(weeklimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	'0.00'	END												as vty_chk_lmt_amt
             , 0																					as vty_chk_lmt_cnt
			 , CASE WHEN limtype = 'B' THEN dbo.ufn_creditlimit(ac.cyclestartday,weekusedb,ac.weekusedend,weekstartdt) 
					WHEN limtype = 'L' THEN '0.00' END												as vty_chk_accm_amt
             , 0																					as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN '0.00' 
					WHEN limtype = 'L' THEN CAST(weekliml as numeric(17,2)) END						as vty_chk_lmt_lter
			 , CASE WHEN limtype = 'B' THEN '0.00' 
					WHEN limtype = 'L' THEN dbo.ufn_creditlimit(ac.cyclestartday,weekusedl,ac.weekusedend,weekstartdt) END				
			 																						as vty_chk_accm_lter
			 , 2 as typeseq
        from ac
        --where not (weeklimb is null and weekliml is null)
        union all
        select compid,cardnumseq,cardnum															as pan_txt
             , 'ROLL'																				as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END		as vty_chk_typ
             , '1800-01-01'																			as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(daylimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	'0.00'	END												as vty_chk_lmt_amt
             , 0																					as vty_chk_lmt_cnt
			 , CASE WHEN limtype = 'B' THEN dbo.ufn_creditlimit(ac.cyclestartday,dayusedb,ac.dayusedend,daystartdt)
					WHEN limtype = 'L' THEN '0.00' END												as vty_chk_accm_amt
             , 0																					as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN '0.00'
					WHEN limtype = 'L' THEN CAST(dayliml as numeric(17,2)) END						as vty_chk_lmt_lter
			 , CASE WHEN limtype = 'B' THEN '0.00'
					WHEN limtype = 'L' THEN dbo.ufn_creditlimit(ac.cyclestartday,dayusedl,ac.dayusedend,daystartdt) END					   
																									as vty_chk_accm_lter
			 , 3 as typeseq
        from ac
        --where not (daylimb is null and dayliml is null)
        union all
        select compid,cardnumseq,cardnum															as pan_txt
             , 'SING'																				as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END		as vty_chk_typ
             , '1800-01-01'																			as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(translimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	'0.00'	END												as vty_chk_lmt_amt
             , 0																					as vty_chk_lmt_cnt
			 , 0.00																					as vty_chk_accm_amt
             , 0																					as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN '0.00'
					WHEN limtype = 'L' THEN CAST(transliml as numeric(17,2)) END					as vty_chk_lmt_lter
             , 0.00																					as vty_chk_accm_lter
			 , 4 as typeseq
        from ac
        --where not (translimb is null and transliml is null)
    ) as c
/*replace_here*/order by compid,c.cardnumseq,typeseq asc

with ac as (
	select id,cardnum,limtype,monthlimb,monthliml,monthusedl,monthusedb,weeklimb,weekusedb,weekliml,weekusedl,daylimb,dayliml,dayusedb,dayusedl,translimb,transliml 
	from card 
	where 1=1
	--and cardnum = '32887562a99bd4d4e2e484a19f8e601c94bd96a20b0c70569bc49d963e77e364'
	union all
	select cardid,cardnum,climtype,cmonthlimb,cmonthliml,cmonthusedl,cmonthusedb,cweeklimb,cweekusedb,cweekliml,cweekusedl,cdaylimb,cdayliml,cdayusedb,cdayusedl,ctranslimb,ctransliml 
	from cardnum where seq <> 0
	--and cardnum = '32887562a99bd4d4e2e484a19f8e601c94bd96a20b0c70569bc49d963e77e364' 
)
select 'maskcard='+pan_txt as 'pan_txt',vty_chk_prd_typ,vty_chk_typ,vty_stt_dte
	,replace(cast(isnull(vty_chk_lmt_amt,0.00) as varchar),'.','') as vty_chk_lmt_amt
	,vty_chk_lmt_cnt
	,replace(cast(isnull(vty_chk_accm_amt,0.00) as varchar),'.','') as vty_chk_accm_amt
	,vty_chk_accm_cnt
	,replace(cast(isnull(vty_chk_lmt_lter,0.00) as varchar),'.','') as vty_chk_lmt_lter
	,replace(cast(isnull(vty_chk_accm_lter,0.00) as varchar),'.','') as vty_chk_accm_lter  
from
    (
        select cardnum                                                                          as pan_txt
             , 'CYCL'                                                                           as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END as vty_chk_typ
             , '1800-01-01'                                                                     as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(monthlimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	0.00	END											as vty_chk_lmt_amt
             , 0                                                                                as vty_chk_lmt_cnt
             , CASE WHEN limtype = 'B' THEN CAST(monthusedb as numeric(17,2)) 
					WHEN limtype = 'L' THEN 0.00 END											as vty_chk_accm_amt
             , 0                                                                                as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN CAST(monthliml as numeric(17,2)) END			    as vty_chk_lmt_lter
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN CAST(monthusedl as numeric(17,2)) END				as vty_chk_accm_lter
        from ac
        --where not (monthlimb is null and monthliml is null)
        union all
        select cardnum                                                                          as pan_txt
             , 'FXWK'                                                                           as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END as vty_chk_typ
             , '1800-01-01'                                                                     as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(weeklimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	'0.00'	END											as vty_chk_lmt_amt
             , 0                                                                                as vty_chk_lmt_cnt
			 , CASE WHEN limtype = 'B' THEN CAST(weekusedb as numeric(17,2)) 
					WHEN limtype = 'L' THEN 0.00 END											as vty_chk_accm_amt
             , 0                                                                                as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN 0.00 
					WHEN limtype = 'L' THEN CAST(weekliml as numeric(17,2)) END					as vty_chk_lmt_lter
			 , CASE WHEN limtype = 'B' THEN 0.00 
					WHEN limtype = 'L' THEN CAST(weekusedl as numeric(17,2)) END				as vty_chk_accm_lter
        from ac
        --where not (weeklimb is null and weekliml is null)
        union all
        select cardnum																			   as pan_txt
             , 'ROLL'                                                                              as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END    as vty_chk_typ
             , '1800-01-01'                                                                        as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(daylimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	'0.00'	END											   as vty_chk_lmt_amt
             , 0                                                                                   as vty_chk_lmt_cnt
			 , CASE WHEN limtype = 'B' THEN CAST(dayusedb as numeric(17,2))
					WHEN limtype = 'L' THEN 0.00 END											   as vty_chk_accm_amt
             , 0                                                                                   as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN CAST(dayliml as numeric(17,2)) END					   as vty_chk_lmt_lter
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN CAST(dayusedl as numeric(17,2)) END					   as vty_chk_accm_lter
        from ac
        --where not (daylimb is null and dayliml is null)
        union all
        select cardnum                                                                             as pan_txt
             , 'SING'                                                                              as vty_chk_prd_typ
             , CASE WHEN limtype = 'B' THEN 'BAHT' WHEN limtype = 'L' THEN 'LTER' ELSE null END    as vty_chk_typ
             , '1800-01-01'                                                                        as vty_stt_dte
             , CASE WHEN limtype = 'B' THEN CAST(translimb as numeric(17,2))                                                 
					WHEN limtype = 'L' THEN	'0.00'	END											   as vty_chk_lmt_amt
             , 0                                                                                   as vty_chk_lmt_cnt
			 , 0.00																				   as vty_chk_accm_amt
             , 0                                                                                   as vty_chk_accm_cnt
			 , CASE WHEN limtype = 'B' THEN 0.00
					WHEN limtype = 'L' THEN CAST(transliml as numeric(17,2)) END				   as vty_chk_lmt_lter
             , 0.00                                                                                as vty_chk_accm_lter
        from ac
        --where not (translimb is null and transliml is null)
    ) as c
/*replace_here*/order by c.pan_txt

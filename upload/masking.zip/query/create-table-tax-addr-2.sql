use tfc
go


create table taxaddr2
(
	id int not null,
	compid varchar(16) not null,
	taxname	varchar(200) null,
	house varchar(20) null,
	moo	varchar(20) null,
	building_village varchar(200) null,
	floor varchar(15) null,
	room varchar(15) null,
	soi	varchar(100) null,
	road varchar(100) null,	
	tambon	varchar(100) null,
	amphoe	varchar(100) null,
	province	varchar(100) null,
	zipcode	varchar(10) null,
	phone	varchar(50) null,
	taxid	varchar(20) null,
	branch	varchar(10) null,
	tophone	varchar(50) null,
	ext	varchar(20) null,
	fax varchar(20) null
)
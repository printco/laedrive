with p as (
	select c.cardnum,pp.id,pp.prodid,prodcode,prodname, prodperm, cardnumseq,cardtypeid
	from (
		select cardnum,prodperm,cardtypeid from card
		union all
		select cardnum,cprodperm,ccardtypeid from cardnum where seq <> 0
	) c
	left join cardnum n on c.cardnum = n.cardnum
	left join prodperm pp on pp.id = c.prodperm
	left join prod p on p.id = pp.prodid
	--where c.cardnum = '1ffcca80163ff553a61c096aca52634e96e43fba0a657ae3f90d58b8a048c7b5'
)
, q as (
	select stuff( (
	select '|' + prodcode
	from prod
	where prodcatid = 1
	for xml path('')
	),1,1,'') as allfuel
) 
select pan_txt,(case when pdt_sev_grp is null or pdt_sev_grp = '' then '99' else pdt_sev_grp end) as pdt_sev_grp 
from (
	select 'maskcard=' + cardnum as pan_txt, stuff((
		select '|' + (case when a1.cardtypeid in (4,5) then (select allfuel from q) else prodcode end) 
		from p as a1
		where a1.cardnum = a2.cardnum
		order by a1.prodid
		for xml path('')
	),1,1,'') as pdt_sev_grp,cardnumseq
	from p as a2
	group by cardnum,cardnumseq
)x
/*replace_here*/order by cardnumseq

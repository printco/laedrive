select
    compid as csr_idn_sky
     , case when cc.iswthcer = 1 and cc.iswth = 1 then '1'
            when cc.iswthcer = 1 and cc.iswth = 0 then '0'
            when c.iswth = 1 then '1' else '0' end as cpe_apl_wht_flg
     ,case when (c.compchainid is null and c.orgtypeid = 1) or (c.compchainid is not null and cc.orgtypeid = 1) then 'GA'
           when (c.compchainid is null and c.orgtypeid = 7) or (c.compchainid is not null and cc.orgtypeid = 7) then 'SE'
           else 'PI' end as cpe_typ_cde
from comp c
         left join compchain cc on c.compchainid = cc.compchainid
/*replace_here*/order by compid
select compid as att_adr_idn_sky
, 'A' as att_ID_type
, compname as att_contact_name
, 'maskcontact=' + contacttel as att_telephone
, contactpos as att_contact_position
, 'maskcontact=' + contactfax as att_fax
, nameoncard as att_Name_on_card
, remark as att_Remark
from comp
/*replace_here*/order by compid